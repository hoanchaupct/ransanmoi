# Game rắn săn mồi bản 3D

Được làm bởi Phat's Dev. Vào một ngày đẹp trời anh ta đã nghĩ ra ý tưởng viết ra một bản nâng cấp của tựa game huyền thoại rắn săn mồi để nhớ lại kỉ niệm tuổi thơ. Và rồi, tựa game này đã được ra đời.
